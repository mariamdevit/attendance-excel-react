export const config = {
    url: 'https://script.google.com/macros/s/AKfycbxl0a9rVsBs6ACLiS--h30B55fMcneNKTQVxM08-qxHegQ_zeR883FHFnMWpTmtZQ5TYQ/exec'
}